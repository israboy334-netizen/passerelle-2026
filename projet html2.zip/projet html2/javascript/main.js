/* =================================================================
   GROUPE LA PASSERELLE NETWORK
   - Loader animé à l'entrée et lors du clic sur un lien interne
   - Menu mobile (hamburger)
   ================================================================= */
(function () {
    "use strict";

    var LOADER_DELAY_OUT = 350; // durée avant de quitter la page (doit matcher le CSS)
    var loader = document.getElementById("page-loader");

    /* -----------------------------------------------------------------
       1. MASQUER LE LOADER UNE FOIS LA PAGE PRÊTE
       ----------------------------------------------------------------- */
    function hideLoader() {
        if (!loader) return;
        loader.classList.add("is-hidden");
        loader.setAttribute("aria-hidden", "true");
        document.body.classList.add("is-ready");
    }

    // On laisse un tout petit délai pour que l'animation soit visible
    // même quand la page se charge très vite (évite l'effet de "flash").
    window.addEventListener("load", function () {
        setTimeout(hideLoader, 250);
    });

    // Sécurité : si "load" tarde trop (images lourdes...), on masque quand même.
    setTimeout(hideLoader, 2500);

    // Quand l'utilisateur revient en arrière (cache bfcache), on s'assure
    // que le loader ne reste pas affiché.
    window.addEventListener("pageshow", function (e) {
        if (e.persisted) hideLoader();
    });

    /* -----------------------------------------------------------------
       2. RÉAFFICHER LE LOADER AU CLIC SUR UN LIEN INTERNE
       ----------------------------------------------------------------- */
    function isInternalNavigableLink(link) {
        if (!link || !link.getAttribute) return false;
        var href = link.getAttribute("href");

        if (!href) return false;
        if (href.startsWith("#")) return false;
        if (href.startsWith("mailto:")) return false;
        if (href.startsWith("tel:")) return false;
        if (href.startsWith("javascript:")) return false;
        if (link.hasAttribute("download")) return false;
        if (link.getAttribute("target") === "_blank") return false;
        if (link.origin && link.origin !== window.location.origin) return false;

        return true;
    }

    document.addEventListener("click", function (e) {
        var link = e.target.closest ? e.target.closest("a") : null;
        if (!link || !isInternalNavigableLink(link)) return;

        var destination = link.href;

        // Si on clique deux fois ou que c'est déjà la page en cours, on laisse faire.
        if (destination === window.location.href) return;

        e.preventDefault();

        if (loader) {
            loader.classList.remove("is-hidden");
            loader.setAttribute("aria-hidden", "false");
        }

        setTimeout(function () {
            window.location.href = destination;
        }, LOADER_DELAY_OUT);
    });

    /* -----------------------------------------------------------------
       3. MENU MOBILE (HAMBURGER)
       ----------------------------------------------------------------- */
    document.addEventListener("DOMContentLoaded", function () {
        var toggleBtn = document.querySelector(".menu-toggle");
        var nav = document.querySelector("header nav");

        if (!toggleBtn || !nav) return;

        function closeMenu() {
            nav.classList.remove("active");
            toggleBtn.setAttribute("aria-expanded", "false");
        }

        function toggleMenu() {
            var isOpen = nav.classList.toggle("active");
            toggleBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
        }

        toggleBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            toggleMenu();
        });

        // Ferme le menu si on clique en dehors
        document.addEventListener("click", function (e) {
            if (nav.classList.contains("active") && !nav.contains(e.target) && e.target !== toggleBtn) {
                closeMenu();
            }
        });

        // Ferme le menu si on clique sur un lien du menu
        nav.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", closeMenu);
        });
    });
})();
