/* =================================================================
   GROUPE LA PASSERELLE NETWORK - LOGIQUE DE TRI ET RECHERCHE
   ================================================================= */
document.addEventListener("DOMContentLoaded", () => {
    // 1. Récupération des éléments HTML du DOM
    const searchInput = document.getElementById("search-service");
    const filterButtons = document.querySelectorAll(".filter-btn");
    const serviceItems = document.querySelectorAll(".service-detail-item");
    const servicesContainer = document.querySelector(".services-detailed-list .container-inner");

    // Cette logique ne concerne que la page Services : on quitte si on n'y est pas.
    if (!servicesContainer) return;

    // Création dynamique d'un message "Aucun résultat" si la recherche est vide
    const noResultMsg = document.createElement("div");
    noResultMsg.className = "no-results-message";
    noResultMsg.style.cssText = "text-align:center; padding:40px 0; font-size:18px; color:var(--texte-gris); font-weight:600; display:none; width:100%;";
    noResultMsg.innerHTML = '<i class="fa-solid fa-circle-xmark" style="color:var(--orange); font-size:32px; margin-bottom:15px; display:block;"></i> Aucun service ne correspond à votre recherche.';
    servicesContainer.appendChild(noResultMsg);

    // Variables d'état pour mémoriser les choix de l'utilisateur
    let currentSearchQuery = "";
    let currentCategoryFilter = "all";

    /* =================================================================
       FONCTION PRINCIPALE : FILTRAGE MULTI-CRITÈRES
       ================================================================= */
    function filterServices() {
        let visibleCount = 0;

        serviceItems.forEach(item => {
            // Extraction des données de l'article pour le test
            const itemCategory = item.getAttribute("data-category");
            
            // On récupère tout le texte de la carte (titre, lead, puces) pour une recherche ultra-large
            const itemText = item.textContent.toLowerCase();

            // Condition 1 : Est-ce que ça correspond à la catégorie sélectionnée ?
            const matchesCategory = (currentCategoryFilter === "all" || itemCategory === currentCategoryFilter);

            // Condition 2 : Est-ce que ça contient le mot-clé tapé ?
            const matchesSearch = itemText.includes(currentSearchQuery);

            // Si le service valide les deux conditions, on l'affiche, sinon on le cache
            if (matchesCategory && matchesSearch) {
                item.classList.remove("is-hidden");
                visibleCount++;
            } else {
                item.classList.add("is-hidden");
            }
        });

        // Gestion de l'affichage du message d'erreur si la grille est vide
        if (visibleCount === 0) {
            noResultMsg.style.display = "block";
        } else {
            noResultMsg.style.display = "none";
        }
    }

    /* =================================================================
       ÉCOUTEURS D'ÉVÉNEMENTS (LISTENERS)
       ================================================================= */

    // Événement A : L'utilisateur tape dans la barre de recherche
    if (searchInput) {
        searchInput.addEventListener("input", (e) => {
            currentSearchQuery = e.target.value.toLowerCase().trim();
            filterServices();
        });
    }

    // Événement B : L'utilisateur clique sur un bouton de catégorie
    filterButtons.forEach(button => {
        button.addEventListener("click", () => {
            // 1. Gestion visuelle : On retire la classe active du bouton précédent
            filterButtons.forEach(btn => btn.classList.remove("active"));
            
            // 2. On applique la classe active sur le bouton cliqué
            button.classList.add("active");

            // 3. On met à jour le filtre et on lance le tri
            currentCategoryFilter = button.getAttribute("data-filter");
            filterServices();
        });
    });
});